package com.cms.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;

@Data // This Lombok annotation automatically creates Getters and Setters for us!
@Document(collection = "Citizen") // Tells MongoDB to create a collection named "Citizen"
public class Citizen {
    @Id // Marks this field as the unique primary key
    private String citizenId;

    private String name;
    private String email;
    private String mobile;
}