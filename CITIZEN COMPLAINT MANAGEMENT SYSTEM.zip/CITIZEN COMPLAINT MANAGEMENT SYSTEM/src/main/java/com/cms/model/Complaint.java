
package com.cms.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;

@Data
@Document(collection = "Complaint")
public class Complaint {
    @Id
    private String complaintId;

    private String title;
    private String description;
    private String status; // Example statuses: PENDING, ASSIGNED, RESOLVED

    // These fields establish the relationships
    private String citizenId;
    private String departmentId;
    private String officerId;
}