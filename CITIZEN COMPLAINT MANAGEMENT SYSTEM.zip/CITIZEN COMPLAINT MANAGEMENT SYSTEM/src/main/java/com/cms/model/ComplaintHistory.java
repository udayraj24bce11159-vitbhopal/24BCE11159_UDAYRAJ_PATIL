package com.cms.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Document(collection = "ComplaintHistory")
public class ComplaintHistory {
    @Id
    private String historyId;

    private String complaintId;
    private String status;
    private LocalDateTime updatedDate;
}