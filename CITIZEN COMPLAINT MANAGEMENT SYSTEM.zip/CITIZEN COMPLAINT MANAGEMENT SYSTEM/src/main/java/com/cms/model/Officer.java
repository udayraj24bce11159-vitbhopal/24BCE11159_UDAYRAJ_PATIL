package com.cms.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;

@Data
@Document(collection = "Officer")
public class Officer {
    @Id
    private String officerId;

    private String officerName;
    private String departmentId; // Links the officer to a specific department
}