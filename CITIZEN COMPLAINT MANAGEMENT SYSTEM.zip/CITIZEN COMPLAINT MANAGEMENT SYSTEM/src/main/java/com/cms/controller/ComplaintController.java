package com.cms.controller;

import com.cms.model.Complaint;
import com.cms.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/complaints")
public class ComplaintController {

    @Autowired
    private ComplaintService complaintService;

    // Create a new complaint
    @PostMapping
    public Complaint createComplaint(@RequestBody Complaint complaint) {
        return complaintService.registerComplaint(complaint);
    }

    // Get all complaints
    @GetMapping
    public List<Complaint> getAllComplaints() {
        return complaintService.getAllComplaints();
    }

    // Get a specific complaint
    @GetMapping("/{id}")
    public Complaint getComplaintById(@PathVariable String id) {
        return complaintService.getComplaintById(id);
    }

    // Update the status of a complaint (e.g., PENDING to RESOLVED)
    @PutMapping("/{id}/status/{status}")
    public Complaint updateComplaintStatus(@PathVariable String id, @PathVariable String status) {
        return complaintService.updateComplaintStatus(id, status);
    }

    // Assign an officer to a complaint
    @PutMapping("/{id}/assign/{officerId}")
    public Complaint assignOfficer(@PathVariable String id, @PathVariable String officerId) {
        return complaintService.assignOfficer(id, officerId);
    }

    // Delete a complaint
    @DeleteMapping("/{id}")
    public String deleteComplaint(@PathVariable String id) {
        complaintService.deleteComplaint(id);
        return "Complaint deleted successfully.";
    }
    @Autowired
    private com.cms.repository.ComplaintHistoryRepository historyRepository;

    @GetMapping("/{id}/history")
    public List<com.cms.model.ComplaintHistory> getComplaintHistory(@PathVariable String id) {
        return historyRepository.findByComplaintId(id);
    }
    @GetMapping("/status/{status}")
    public List<Complaint> getComplaintsByStatus(@PathVariable String status) {
        return complaintService.getAllComplaints().stream()
                .filter(c -> c.getStatus().equalsIgnoreCase(status))
                .toList();
    }

    @GetMapping("/citizen/{citizenId}")
    public List<Complaint> getComplaintsByCitizen(@PathVariable String citizenId) {
        return complaintService.getAllComplaints().stream()
                .filter(c -> c.getCitizenId().equals(citizenId))
                .toList();
    }
}