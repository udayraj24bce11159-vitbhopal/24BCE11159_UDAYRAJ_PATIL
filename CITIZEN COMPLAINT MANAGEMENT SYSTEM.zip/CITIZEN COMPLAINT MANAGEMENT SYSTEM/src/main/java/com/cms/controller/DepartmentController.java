package com.cms.controller;

import com.cms.model.Department;
import com.cms.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping
    public Department addDepartment(@RequestBody Department department) {
        return departmentService.addDepartment(department);
    }

    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentService.getAllDepartments();
    }

    @DeleteMapping("/{id}")
    public String deleteDepartment(@PathVariable String id) {
        departmentService.deleteDepartment(id);
        return "Department deleted successfully.";
    }
    @GetMapping("/{id}")
    public Department getDepartmentById(@PathVariable String id) {
        return departmentService.getAllDepartments().stream()
                .filter(d -> d.getDepartmentId().equals(id))
                .findFirst()
                .orElse(null);
    }
}