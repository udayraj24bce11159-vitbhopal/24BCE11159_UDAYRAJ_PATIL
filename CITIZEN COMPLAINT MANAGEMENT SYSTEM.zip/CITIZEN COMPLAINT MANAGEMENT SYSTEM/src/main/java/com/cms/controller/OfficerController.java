package com.cms.controller;

import com.cms.model.Officer;
import com.cms.service.OfficerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/officers")
public class OfficerController {

    @Autowired
    private OfficerService officerService;

    @PostMapping
    public Officer addOfficer(@RequestBody Officer officer) {
        return officerService.addOfficer(officer);
    }

    @GetMapping
    public List<Officer> getAllOfficers() {
        return officerService.getAllOfficers();
    }

    @DeleteMapping("/{id}")
    public String deleteOfficer(@PathVariable String id) {
        officerService.deleteOfficer(id);
        return "Officer deleted successfully.";
    }
    @GetMapping("/{id}")
    public Officer getOfficerById(@PathVariable String id) {
        return officerService.getAllOfficers().stream()
                .filter(o -> o.getOfficerId().equals(id))
                .findFirst()
                .orElse(null);
    }
}