
package com.cms.controller;

import com.cms.model.Complaint;
import com.cms.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private ComplaintService complaintService;

    // 1. Get Total Complaints
    @GetMapping("/total-complaints")
    public String getTotalComplaints() {
        int total = complaintService.getAllComplaints().size();
        return "Total Complaints Registered: " + total;
    }

    // 2. Get Pending Complaints
    @GetMapping("/pending-complaints")
    public String getPendingComplaints() {
        long pendingCount = complaintService.getAllComplaints().stream()
                .filter(c -> "PENDING".equalsIgnoreCase(c.getStatus()))
                .count();
        return "Pending Complaints: " + pendingCount;
    }

    // 3. Get Resolved Complaints
    @GetMapping("/resolved-complaints")
    public String getResolvedComplaints() {
        long resolvedCount = complaintService.getAllComplaints().stream()
                .filter(c -> "RESOLVED".equalsIgnoreCase(c.getStatus()))
                .count();
        return "Resolved Complaints: " + resolvedCount;
    }

    // 4. Get Department-Wise Report
    @GetMapping("/department-wise-report")
    public Map<String, Long> getDepartmentWiseReport() {
        // This takes all complaints, groups them by their Department ID, and counts how many are in each group
        return complaintService.getAllComplaints().stream()
                .collect(Collectors.groupingBy(
                        Complaint::getDepartmentId,
                        Collectors.counting()
                ));
    }
}