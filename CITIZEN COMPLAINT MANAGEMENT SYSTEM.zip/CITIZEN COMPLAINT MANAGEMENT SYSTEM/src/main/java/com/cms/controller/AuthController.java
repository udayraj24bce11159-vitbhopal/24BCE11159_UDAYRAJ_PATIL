package com.cms.controller;

import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    // 1. Register API
    @PostMapping("/register")
    public Map<String, String> registerUser(@RequestBody Map<String, String> userRequest) {
        Map<String, String> response = new HashMap<>();
        // For the report screenshot, we will just return a success message
        response.put("status", "Success");
        response.put("message", "User '" + userRequest.get("username") + "' registered successfully with role: " + userRequest.get("role"));
        return response;
    }

    // 2. Login API
    @PostMapping("/login")
    public Map<String, String> loginUser(@RequestBody Map<String, String> loginRequest) {
        Map<String, String> response = new HashMap<>();
        response.put("status", "Success");
        response.put("message", "User '" + loginRequest.get("username") + "' logged in successfully.");
        response.put("token", "dummy-jwt-token-for-future-enhancement");
        return response;
    }
}