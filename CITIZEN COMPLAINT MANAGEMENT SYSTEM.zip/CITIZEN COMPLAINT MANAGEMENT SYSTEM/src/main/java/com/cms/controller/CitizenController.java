package com.cms.controller;

import com.cms.model.Citizen;
import com.cms.service.CitizenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // Tells Spring this class handles web requests and returns JSON
@RequestMapping("/api/citizens") // Base URL for all methods in this class
public class CitizenController {

    @Autowired
    private CitizenService citizenService;

    @PostMapping
    public Citizen createCitizen(@RequestBody Citizen citizen) {
        return citizenService.registerCitizen(citizen);
    }

    @GetMapping
    public List<Citizen> getAllCitizens() {
        return citizenService.getAllCitizens();
    }

    @GetMapping("/{id}")
    public Citizen getCitizenById(@PathVariable String id) {
        return citizenService.getCitizenById(id);
    }

    @DeleteMapping("/{id}")
    public String deleteCitizen(@PathVariable String id) {
        citizenService.deleteCitizen(id);
        return "Citizen deleted successfully.";
    }
    @PutMapping("/{id}")
    public Citizen updateCitizen(@PathVariable String id, @RequestBody Citizen updatedCitizen) {
        updatedCitizen.setCitizenId(id);
        return citizenService.registerCitizen(updatedCitizen); // Save acts as update in Mongo
    }
}