package com.cms.service;

import com.cms.model.Citizen;
import com.cms.repository.CitizenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CitizenService {

    @Autowired // This tells Spring to automatically inject our CitizenRepository here
    private CitizenRepository citizenRepository;

    public Citizen registerCitizen(Citizen citizen) {
        return citizenRepository.save(citizen);
    }

    public List<Citizen> getAllCitizens() {
        return citizenRepository.findAll();
    }

    public Citizen getCitizenById(String id) {
        return citizenRepository.findById(id).orElse(null);
    }

    public void deleteCitizen(String id) {
        citizenRepository.deleteById(id);
    }
}