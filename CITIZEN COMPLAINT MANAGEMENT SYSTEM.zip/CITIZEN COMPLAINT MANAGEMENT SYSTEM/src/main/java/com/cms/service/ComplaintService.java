package com.cms.service;

import com.cms.model.Complaint;
import com.cms.model.ComplaintHistory;
import com.cms.repository.ComplaintHistoryRepository;
import com.cms.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepository complaintRepository;

    @Autowired
    private ComplaintHistoryRepository historyRepository;

    // Registering a new complaint
    public Complaint registerComplaint(Complaint complaint) {
        complaint.setStatus("PENDING"); // Force status to PENDING on creation
        Complaint savedComplaint = complaintRepository.save(complaint);

        // Record this initial creation in the history
        recordHistory(savedComplaint.getComplaintId(), "PENDING");

        return savedComplaint;
    }

    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll();
    }

    public Complaint getComplaintById(String id) {
        return complaintRepository.findById(id).orElse(null);
    }

    // Updating status and saving history
    public Complaint updateComplaintStatus(String id, String newStatus) {
        Complaint complaint = complaintRepository.findById(id).orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setStatus(newStatus);
        Complaint updatedComplaint = complaintRepository.save(complaint);

        // Record the change in history
        recordHistory(id, newStatus);

        return updatedComplaint;
    }

    // Assign an officer to a complaint
    public Complaint assignOfficer(String complaintId, String officerId) {
        Complaint complaint = complaintRepository.findById(complaintId).orElseThrow();
        complaint.setOfficerId(officerId);
        complaint.setStatus("ASSIGNED");

        recordHistory(complaintId, "ASSIGNED");
        return complaintRepository.save(complaint);
    }

    public void deleteComplaint(String id) {
        complaintRepository.deleteById(id);
    }

    // Helper method to keep code clean
    private void recordHistory(String complaintId, String status) {
        ComplaintHistory history = new ComplaintHistory();
        history.setComplaintId(complaintId);
        history.setStatus(status);
        history.setUpdatedDate(LocalDateTime.now()); // Stamps the exact date and time
        historyRepository.save(history);
    }
}