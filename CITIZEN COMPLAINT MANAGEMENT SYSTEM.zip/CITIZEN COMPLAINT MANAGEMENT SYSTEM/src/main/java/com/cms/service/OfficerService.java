package com.cms.service;

import com.cms.model.Officer;
import com.cms.repository.OfficerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OfficerService {

    @Autowired
    private OfficerRepository officerRepository;

    public Officer addOfficer(Officer officer) {
        return officerRepository.save(officer);
    }

    public List<Officer> getAllOfficers() {
        return officerRepository.findAll();
    }

    public void deleteOfficer(String id) {
        officerRepository.deleteById(id);
    }
}