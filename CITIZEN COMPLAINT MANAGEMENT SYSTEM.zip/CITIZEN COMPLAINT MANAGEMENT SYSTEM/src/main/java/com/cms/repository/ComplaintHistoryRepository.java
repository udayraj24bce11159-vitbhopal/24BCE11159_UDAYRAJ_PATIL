package com.cms.repository;

import com.cms.model.ComplaintHistory;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ComplaintHistoryRepository extends MongoRepository<ComplaintHistory, String> {
    // To get the full timeline of a specific complaint
    List<ComplaintHistory> findByComplaintId(String complaintId);
}