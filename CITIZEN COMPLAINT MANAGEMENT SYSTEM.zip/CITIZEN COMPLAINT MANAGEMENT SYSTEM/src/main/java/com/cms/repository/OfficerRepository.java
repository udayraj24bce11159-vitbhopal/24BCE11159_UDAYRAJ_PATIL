package com.cms.repository;

import com.cms.model.Officer;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface OfficerRepository extends MongoRepository<Officer, String> {
    // Useful if we want to find all officers working in a specific department
    List<Officer> findByDepartmentId(String departmentId);
}