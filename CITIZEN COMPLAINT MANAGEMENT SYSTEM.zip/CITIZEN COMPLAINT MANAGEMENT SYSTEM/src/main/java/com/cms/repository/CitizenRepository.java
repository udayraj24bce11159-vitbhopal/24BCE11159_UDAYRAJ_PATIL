package com.cms.repository;

import com.cms.model.Citizen;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CitizenRepository extends MongoRepository<Citizen, String> {
    // MongoRepository gives us save(), findAll(), findById(), deleteById() automatically!
}