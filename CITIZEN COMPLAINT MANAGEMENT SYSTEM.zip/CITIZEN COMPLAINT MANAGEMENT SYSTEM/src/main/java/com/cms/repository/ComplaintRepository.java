package com.cms.repository;

import com.cms.model.Complaint;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ComplaintRepository extends MongoRepository<Complaint, String> {
    // Custom search methods based on your project requirements
    List<Complaint> findByStatus(String status);
    List<Complaint> findByCitizenId(String citizenId);
    List<Complaint> findByDepartmentId(String departmentId);
}